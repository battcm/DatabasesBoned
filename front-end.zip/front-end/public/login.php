<?php
echo yo;
$email=$_POST['email'];
$password=$_POST['password'];
//database connecion
echo $email;
?>